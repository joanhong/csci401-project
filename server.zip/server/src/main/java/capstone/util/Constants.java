package capstone.util;

public class Constants {
	public static String STUDENT = "student";
	public static String STAKEHOLDER = "stakeholder";
	public static String ADMIN = "admin";
	public static String EMPTY = "";
}
