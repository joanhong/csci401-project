package capstone.repository;


import org.springframework.data.repository.CrudRepository;
import capstone.model.AdminConfiguration;

public interface AdminConfigurationRepository extends CrudRepository<AdminConfiguration, Long> {

}
